﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAndorRenameAndSaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ЦветКонтураToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ЦветToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CGToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InvisibleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InvisibleAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox5 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox6 = New System.Windows.Forms.ToolStripTextBox()
        Me.CreateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReturnToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearCBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveFromScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToCBFromScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PastFromCBToScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox2 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox3 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox8 = New System.Windows.Forms.ToolStripTextBox()
        Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpacityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Opacity1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackGraundColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GradientBCkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DelateToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearPBToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearCBToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.СведенияToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ОПрограммеToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripComboBox6 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox7 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripTextBox12 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox9 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox11 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox17 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox2 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripTextBox4 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripComboBox3 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox4 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripComboBox5 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripTextBox7 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox10 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripTextBox13 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox14 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox15 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox16 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton8 = New System.Windows.Forms.ToolStripButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.SaveFileDialog2 = New System.Windows.Forms.SaveFileDialog()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.SaveFileDialog3 = New System.Windows.Forms.SaveFileDialog()
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 641)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(94, 108)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox1, "Picture signature/One click left- Show All" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Two click right- scrinshot")
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ToolStripTextBox1, Me.ToolStripTextBox5, Me.ToolStripTextBox6, Me.CreateToolStripMenuItem, Me.ToolStripTextBox2, Me.ToolStripTextBox3, Me.ToolStripTextBox8, Me.ServiceToolStripMenuItem, Me.ServiceToolStripMenuItem1, Me.ToolStripComboBox6, Me.ToolStripComboBox7, Me.ToolStripTextBox12, Me.ToolStripTextBox9, Me.ToolStripTextBox11, Me.ToolStripTextBox17})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1222, 25)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.BackColor = System.Drawing.Color.Gold
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem, Me.SaveAndorRenameAndSaveToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ЦветКонтураToolStripMenuItem, Me.ЦветToolStripMenuItem, Me.CGToolStripMenuItem, Me.InvisibleToolStripMenuItem, Me.InvisibleAllToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 21)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'SaveAndorRenameAndSaveToolStripMenuItem
        '
        Me.SaveAndorRenameAndSaveToolStripMenuItem.Name = "SaveAndorRenameAndSaveToolStripMenuItem"
        Me.SaveAndorRenameAndSaveToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.SaveAndorRenameAndSaveToolStripMenuItem.Text = "Save and/or rename and save"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ЦветКонтураToolStripMenuItem
        '
        Me.ЦветКонтураToolStripMenuItem.Name = "ЦветКонтураToolStripMenuItem"
        Me.ЦветКонтураToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.ЦветКонтураToolStripMenuItem.Text = "Цвет контура"
        '
        'ЦветToolStripMenuItem
        '
        Me.ЦветToolStripMenuItem.Name = "ЦветToolStripMenuItem"
        Me.ЦветToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.ЦветToolStripMenuItem.Text = "Цвет"
        '
        'CGToolStripMenuItem
        '
        Me.CGToolStripMenuItem.Name = "CGToolStripMenuItem"
        Me.CGToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.CGToolStripMenuItem.Text = "CG"
        '
        'InvisibleToolStripMenuItem
        '
        Me.InvisibleToolStripMenuItem.Name = "InvisibleToolStripMenuItem"
        Me.InvisibleToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.InvisibleToolStripMenuItem.Text = "Invisible "
        '
        'InvisibleAllToolStripMenuItem
        '
        Me.InvisibleAllToolStripMenuItem.Name = "InvisibleAllToolStripMenuItem"
        Me.InvisibleAllToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.InvisibleAllToolStripMenuItem.Text = "Invisible All"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(229, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.AutoSize = False
        Me.ToolStripTextBox1.BackColor = System.Drawing.SystemColors.Menu
        Me.ToolStripTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(35, 23)
        Me.ToolStripTextBox1.ToolTipText = "цвет абриса"
        '
        'ToolStripTextBox5
        '
        Me.ToolStripTextBox5.AutoSize = False
        Me.ToolStripTextBox5.BackColor = System.Drawing.SystemColors.Menu
        Me.ToolStripTextBox5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox5.Name = "ToolStripTextBox5"
        Me.ToolStripTextBox5.Size = New System.Drawing.Size(35, 23)
        Me.ToolStripTextBox5.ToolTipText = "цвет заливки кривой"
        '
        'ToolStripTextBox6
        '
        Me.ToolStripTextBox6.AutoSize = False
        Me.ToolStripTextBox6.BackColor = System.Drawing.SystemColors.Menu
        Me.ToolStripTextBox6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox6.Name = "ToolStripTextBox6"
        Me.ToolStripTextBox6.Size = New System.Drawing.Size(35, 23)
        Me.ToolStripTextBox6.Text = "1"
        Me.ToolStripTextBox6.ToolTipText = "размер, толщина линии прорисовки"
        '
        'CreateToolStripMenuItem
        '
        Me.CreateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateToolStripMenuItem1, Me.ReturnToolStripMenuItem, Me.SaveImageToolStripMenuItem, Me.ClearCBToolStripMenuItem, Me.SaveFromScreenToolStripMenuItem, Me.CopyToCBFromScreenToolStripMenuItem, Me.PastFromCBToScreenToolStripMenuItem})
        Me.CreateToolStripMenuItem.Name = "CreateToolStripMenuItem"
        Me.CreateToolStripMenuItem.Size = New System.Drawing.Size(57, 21)
        Me.CreateToolStripMenuItem.Text = "Format"
        '
        'CreateToolStripMenuItem1
        '
        Me.CreateToolStripMenuItem1.Name = "CreateToolStripMenuItem1"
        Me.CreateToolStripMenuItem1.Size = New System.Drawing.Size(274, 22)
        Me.CreateToolStripMenuItem1.Text = "Create"
        '
        'ReturnToolStripMenuItem
        '
        Me.ReturnToolStripMenuItem.Name = "ReturnToolStripMenuItem"
        Me.ReturnToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.ReturnToolStripMenuItem.Text = "Return"
        '
        'SaveImageToolStripMenuItem
        '
        Me.SaveImageToolStripMenuItem.Name = "SaveImageToolStripMenuItem"
        Me.SaveImageToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.SaveImageToolStripMenuItem.Text = "Save Image"
        '
        'ClearCBToolStripMenuItem
        '
        Me.ClearCBToolStripMenuItem.Name = "ClearCBToolStripMenuItem"
        Me.ClearCBToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.ClearCBToolStripMenuItem.Text = "Clear CB"
        '
        'SaveFromScreenToolStripMenuItem
        '
        Me.SaveFromScreenToolStripMenuItem.Name = "SaveFromScreenToolStripMenuItem"
        Me.SaveFromScreenToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.SaveFromScreenToolStripMenuItem.Text = "Save from screen Selected Area"
        '
        'CopyToCBFromScreenToolStripMenuItem
        '
        Me.CopyToCBFromScreenToolStripMenuItem.Name = "CopyToCBFromScreenToolStripMenuItem"
        Me.CopyToCBFromScreenToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.CopyToCBFromScreenToolStripMenuItem.Text = "Copy to CB from screen Selected Area"
        '
        'PastFromCBToScreenToolStripMenuItem
        '
        Me.PastFromCBToScreenToolStripMenuItem.Name = "PastFromCBToScreenToolStripMenuItem"
        Me.PastFromCBToScreenToolStripMenuItem.Size = New System.Drawing.Size(274, 22)
        Me.PastFromCBToScreenToolStripMenuItem.Text = "Past from CB to screen"
        '
        'ToolStripTextBox2
        '
        Me.ToolStripTextBox2.AutoSize = False
        Me.ToolStripTextBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.ToolStripTextBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox2.Name = "ToolStripTextBox2"
        Me.ToolStripTextBox2.Size = New System.Drawing.Size(25, 23)
        Me.ToolStripTextBox2.Text = "0"
        Me.ToolStripTextBox2.ToolTipText = "оттуп верхнего левого угла  холста от левого края клинтской области"
        '
        'ToolStripTextBox3
        '
        Me.ToolStripTextBox3.AutoSize = False
        Me.ToolStripTextBox3.BackColor = System.Drawing.SystemColors.Menu
        Me.ToolStripTextBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox3.Name = "ToolStripTextBox3"
        Me.ToolStripTextBox3.Size = New System.Drawing.Size(25, 23)
        Me.ToolStripTextBox3.Text = "-85"
        Me.ToolStripTextBox3.ToolTipText = "Величина отступа левого верхнего угла холста от верхнего края клинтской области"
        '
        'ToolStripTextBox8
        '
        Me.ToolStripTextBox8.AutoSize = False
        Me.ToolStripTextBox8.BackColor = System.Drawing.SystemColors.Menu
        Me.ToolStripTextBox8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox8.Name = "ToolStripTextBox8"
        Me.ToolStripTextBox8.Size = New System.Drawing.Size(200, 23)
        Me.ToolStripTextBox8.ToolTipText = "координаты прорисовки простейших фигур рисования "
        '
        'ServiceToolStripMenuItem
        '
        Me.ServiceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpacityToolStripMenuItem, Me.Opacity1ToolStripMenuItem, Me.BackGraundColorToolStripMenuItem, Me.GradientBCkToolStripMenuItem, Me.ClearToolStripMenuItem, Me.DelateToolStripMenuItem1, Me.ClearPBToolStripMenuItem, Me.ClearCBToolStripMenuItem1})
        Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
        Me.ServiceToolStripMenuItem.Size = New System.Drawing.Size(50, 21)
        Me.ServiceToolStripMenuItem.Text = "Decor"
        '
        'OpacityToolStripMenuItem
        '
        Me.OpacityToolStripMenuItem.Name = "OpacityToolStripMenuItem"
        Me.OpacityToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.OpacityToolStripMenuItem.Text = "Opacity"
        '
        'Opacity1ToolStripMenuItem
        '
        Me.Opacity1ToolStripMenuItem.Name = "Opacity1ToolStripMenuItem"
        Me.Opacity1ToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.Opacity1ToolStripMenuItem.Text = "Opacity1"
        '
        'BackGraundColorToolStripMenuItem
        '
        Me.BackGraundColorToolStripMenuItem.Name = "BackGraundColorToolStripMenuItem"
        Me.BackGraundColorToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.BackGraundColorToolStripMenuItem.Text = "Back Graund Color"
        '
        'GradientBCkToolStripMenuItem
        '
        Me.GradientBCkToolStripMenuItem.Name = "GradientBCkToolStripMenuItem"
        Me.GradientBCkToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.GradientBCkToolStripMenuItem.Text = "Gradient BCk"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'DelateToolStripMenuItem1
        '
        Me.DelateToolStripMenuItem1.Name = "DelateToolStripMenuItem1"
        Me.DelateToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.DelateToolStripMenuItem1.Text = "Delate and Exit"
        '
        'ClearPBToolStripMenuItem
        '
        Me.ClearPBToolStripMenuItem.Name = "ClearPBToolStripMenuItem"
        Me.ClearPBToolStripMenuItem.Size = New System.Drawing.Size(173, 22)
        Me.ClearPBToolStripMenuItem.Text = "Clear PB"
        '
        'ClearCBToolStripMenuItem1
        '
        Me.ClearCBToolStripMenuItem1.Name = "ClearCBToolStripMenuItem1"
        Me.ClearCBToolStripMenuItem1.Size = New System.Drawing.Size(173, 22)
        Me.ClearCBToolStripMenuItem1.Text = "Clear CB"
        '
        'ServiceToolStripMenuItem1
        '
        Me.ServiceToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.СведенияToolStripMenuItem1, Me.ОПрограммеToolStripMenuItem1})
        Me.ServiceToolStripMenuItem1.Name = "ServiceToolStripMenuItem1"
        Me.ServiceToolStripMenuItem1.Size = New System.Drawing.Size(56, 21)
        Me.ServiceToolStripMenuItem1.Text = "Service"
        '
        'СведенияToolStripMenuItem1
        '
        Me.СведенияToolStripMenuItem1.Name = "СведенияToolStripMenuItem1"
        Me.СведенияToolStripMenuItem1.Size = New System.Drawing.Size(149, 22)
        Me.СведенияToolStripMenuItem1.Text = "Сведения"
        '
        'ОПрограммеToolStripMenuItem1
        '
        Me.ОПрограммеToolStripMenuItem1.Name = "ОПрограммеToolStripMenuItem1"
        Me.ОПрограммеToolStripMenuItem1.Size = New System.Drawing.Size(149, 22)
        Me.ОПрограммеToolStripMenuItem1.Text = "О программе"
        '
        'ToolStripComboBox6
        '
        Me.ToolStripComboBox6.Items.AddRange(New Object() {"Arial", "Bondoni MT", "Book Antiqua", "Bookman Old Style", "Calisto MT", "Castellar", "Century Gothic", "Century Schoolbook", "Comic Sans MS", "Courier", "Courier New", "Elephant", "Forte", "French Script MT", "Garamond", "Georgia", "Gigi", "Impact", "Kartika", "Latha", "Lucida Console", "Lucida Sans", "Mangal", "Marlett", "Microsoft Sans Serif", "MS Reference Sans Serif", "Palace Script MT", "Palatio Linotype", "Papurus", "Perpetua", "Rage Italic", "Rockwell", "Script MT Bold", "Symbol", "Tahoma", "Terminal", "Times New Roman", "Trebuchet MS", "Tunga", "Verdana", "Vrinda", "Webdings", "Wingdings"})
        Me.ToolStripComboBox6.Name = "ToolStripComboBox6"
        Me.ToolStripComboBox6.Size = New System.Drawing.Size(125, 21)
        '
        'ToolStripComboBox7
        '
        Me.ToolStripComboBox7.AutoSize = False
        Me.ToolStripComboBox7.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72"})
        Me.ToolStripComboBox7.Name = "ToolStripComboBox7"
        Me.ToolStripComboBox7.Size = New System.Drawing.Size(35, 23)
        Me.ToolStripComboBox7.Text = "14"
        '
        'ToolStripTextBox12
        '
        Me.ToolStripTextBox12.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox12.Name = "ToolStripTextBox12"
        Me.ToolStripTextBox12.Size = New System.Drawing.Size(35, 21)
        Me.ToolStripTextBox12.Text = "1"
        '
        'ToolStripTextBox9
        '
        Me.ToolStripTextBox9.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox9.Name = "ToolStripTextBox9"
        Me.ToolStripTextBox9.Size = New System.Drawing.Size(35, 21)
        Me.ToolStripTextBox9.Text = "90"
        '
        'ToolStripTextBox11
        '
        Me.ToolStripTextBox11.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox11.Name = "ToolStripTextBox11"
        Me.ToolStripTextBox11.Size = New System.Drawing.Size(35, 21)
        Me.ToolStripTextBox11.Text = "90"
        '
        'ToolStripTextBox17
        '
        Me.ToolStripTextBox17.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox17.Name = "ToolStripTextBox17"
        Me.ToolStripTextBox17.Size = New System.Drawing.Size(200, 21)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton2, Me.ToolStripButton1, Me.ToolStripComboBox1, Me.ToolStripComboBox2, Me.ToolStripTextBox4, Me.ToolStripComboBox3, Me.ToolStripComboBox4, Me.ToolStripButton3, Me.ToolStripComboBox5, Me.ToolStripButton4, Me.ToolStripButton5, Me.ToolStripTextBox7, Me.ToolStripTextBox10, Me.ToolStripSeparator1, Me.ToolStripSeparator2, Me.ToolStripTextBox13, Me.ToolStripTextBox14, Me.ToolStripTextBox15, Me.ToolStripTextBox16, Me.ToolStripButton6, Me.ToolStripButton7, Me.ToolStripButton8})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 25)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1222, 20)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.AutoSize = False
        Me.ToolStripButton2.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton2.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(70, 20)
        Me.ToolStripButton2.Text = "Opacity1"
        Me.ToolStripButton2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolStripButton2.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.AutoSize = False
        Me.ToolStripButton1.BackColor = System.Drawing.Color.Gold
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(70, 20)
        Me.ToolStripButton1.Text = "Opacity"
        Me.ToolStripButton1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolStripButton1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.AutoSize = False
        Me.ToolStripComboBox1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.ToolStripComboBox1.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160", "170", "180", "190", "200", "210", "220", "240", "260", "280", "300", "320", "340", "360", "380", "400", "430", "440", "460", "480", "500", "520", "540", "560", "580", "600", "620", "640", "660", "680", "700", "720", "740", "760", "780", "800", "820", "840", "860", "880", "900", "920", "940", "960", "980", "1000", "1010", "1020", "1040", "1060", "1080", "1100", "1200", "1300", "1400", "1500"})
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(50, 23)
        Me.ToolStripComboBox1.Text = "1200"
        Me.ToolStripComboBox1.ToolTipText = "ширина холста"
        '
        'ToolStripComboBox2
        '
        Me.ToolStripComboBox2.AutoSize = False
        Me.ToolStripComboBox2.BackColor = System.Drawing.SystemColors.MenuBar
        Me.ToolStripComboBox2.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "110", "120", "130", "140", "150", "160", "170", "180", "190", "200", "210", "220", "240", "260", "280", "300", "320", "340", "360", "380", "400", "430", "440", "460", "480", "500", "520", "540", "560", "580", "600", "620", "640", "660", "680", "700", "720", "740", "760", "780", "800", "820", "840", "860", "880", "900", "920", "940", "960", "980", "1000", "1010", "1020", "1040", "1060", "1080", "1100", "1200", "1300", "1400", "1500"})
        Me.ToolStripComboBox2.Name = "ToolStripComboBox2"
        Me.ToolStripComboBox2.Size = New System.Drawing.Size(50, 23)
        Me.ToolStripComboBox2.Text = "700"
        Me.ToolStripComboBox2.ToolTipText = "Высота холста в пикселях" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'ToolStripTextBox4
        '
        Me.ToolStripTextBox4.AutoSize = False
        Me.ToolStripTextBox4.BackColor = System.Drawing.SystemColors.MenuBar
        Me.ToolStripTextBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox4.Name = "ToolStripTextBox4"
        Me.ToolStripTextBox4.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripTextBox4.Text = "55"
        Me.ToolStripTextBox4.ToolTipText = "Угол градиента, пропорциональности соотношения цветов"
        '
        'ToolStripComboBox3
        '
        Me.ToolStripComboBox3.AutoSize = False
        Me.ToolStripComboBox3.BackColor = System.Drawing.SystemColors.MenuBar
        Me.ToolStripComboBox3.FlatStyle = System.Windows.Forms.FlatStyle.Standard
        Me.ToolStripComboBox3.Name = "ToolStripComboBox3"
        Me.ToolStripComboBox3.Size = New System.Drawing.Size(150, 23)
        Me.ToolStripComboBox3.Sorted = True
        Me.ToolStripComboBox3.ToolTipText = "первый цвет в градиентной заливке"
        '
        'ToolStripComboBox4
        '
        Me.ToolStripComboBox4.AutoSize = False
        Me.ToolStripComboBox4.BackColor = System.Drawing.SystemColors.MenuBar
        Me.ToolStripComboBox4.FlatStyle = System.Windows.Forms.FlatStyle.Standard
        Me.ToolStripComboBox4.Name = "ToolStripComboBox4"
        Me.ToolStripComboBox4.Size = New System.Drawing.Size(150, 23)
        Me.ToolStripComboBox4.ToolTipText = "второй цвет в градиентной заливке"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.AutoSize = False
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(70, 20)
        Me.ToolStripButton3.Text = "Gradient BC"
        '
        'ToolStripComboBox5
        '
        Me.ToolStripComboBox5.Items.AddRange(New Object() {"DashedLine", "ThickLine", "SolidBox"})
        Me.ToolStripComboBox5.Name = "ToolStripComboBox5"
        Me.ToolStripComboBox5.Size = New System.Drawing.Size(121, 20)
        Me.ToolStripComboBox5.ToolTipText = "Color of the text" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Цвет текста" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.AutoSize = False
        Me.ToolStripButton4.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripButton4.Text = "R-E"
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.AutoSize = False
        Me.ToolStripButton5.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), System.Drawing.Image)
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(35, 20)
        Me.ToolStripButton5.Text = "E-R"
        '
        'ToolStripTextBox7
        '
        Me.ToolStripTextBox7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox7.Name = "ToolStripTextBox7"
        Me.ToolStripTextBox7.Size = New System.Drawing.Size(40, 20)
        Me.ToolStripTextBox7.Text = "35"
        Me.ToolStripTextBox7.ToolTipText = "Числовые значения  размера прорисовки вееров прямоугольников и овалов, в градиетн" &
    "ой заливке, условно случайного выбора, протягиванием "
        '
        'ToolStripTextBox10
        '
        Me.ToolStripTextBox10.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox10.Name = "ToolStripTextBox10"
        Me.ToolStripTextBox10.Size = New System.Drawing.Size(40, 20)
        Me.ToolStripTextBox10.Text = "35"
        Me.ToolStripTextBox10.ToolTipText = "Числовые значения прорисовки веера прямоугольников и овалов," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "в градиентной залив" &
    "ке условно случайного выбора."
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 20)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 20)
        '
        'ToolStripTextBox13
        '
        Me.ToolStripTextBox13.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox13.Name = "ToolStripTextBox13"
        Me.ToolStripTextBox13.Size = New System.Drawing.Size(27, 20)
        Me.ToolStripTextBox13.Text = "1"
        '
        'ToolStripTextBox14
        '
        Me.ToolStripTextBox14.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox14.Name = "ToolStripTextBox14"
        Me.ToolStripTextBox14.Size = New System.Drawing.Size(27, 20)
        Me.ToolStripTextBox14.Text = "97"
        '
        'ToolStripTextBox15
        '
        Me.ToolStripTextBox15.AutoSize = False
        Me.ToolStripTextBox15.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox15.Name = "ToolStripTextBox15"
        Me.ToolStripTextBox15.Size = New System.Drawing.Size(27, 20)
        Me.ToolStripTextBox15.Text = "1"
        '
        'ToolStripTextBox16
        '
        Me.ToolStripTextBox16.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox16.Name = "ToolStripTextBox16"
        Me.ToolStripTextBox16.Size = New System.Drawing.Size(27, 20)
        Me.ToolStripTextBox16.Text = "1"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.BackColor = System.Drawing.Color.Maroon
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(61, 17)
        Me.ToolStripButton6.Text = "SaveFrScr"
        Me.ToolStripButton6.ToolTipText = "Выделить область копирования, затем сохранить." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Средняя кнопка,в нижней части пан" &
    "ели " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "управления. Окна значений... " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Протягивание мышью."
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.AutoSize = False
        Me.ToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton7.Image = CType(resources.GetObject("ToolStripButton7.Image"), System.Drawing.Image)
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(29, 19)
        Me.ToolStripButton7.Text = "Cp"
        Me.ToolStripButton7.ToolTipText = "Cp. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Copy to clipboad from selected area." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Опция копирования в буфер обмена" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "выд" &
    "еленной области поля прорисовки. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'ToolStripButton8
        '
        Me.ToolStripButton8.AutoSize = False
        Me.ToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton8.Image = CType(resources.GetObject("ToolStripButton8.Image"), System.Drawing.Image)
        Me.ToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton8.Name = "ToolStripButton8"
        Me.ToolStripButton8.Size = New System.Drawing.Size(29, 19)
        Me.ToolStripButton8.Text = "Blc"
        Me.ToolStripButton8.ToolTipText = "Blc Блокирует элементы происовки вертикального" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " кластера."
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "*.jpeg;"
        Me.OpenFileDialog1.FileName = "File Name"
        Me.OpenFileDialog1.Filter = resources.GetString("OpenFileDialog1.Filter")
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "Easy malbert"
        Me.SaveFileDialog1.Filter = resources.GetString("SaveFileDialog1.Filter")
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(27, 42)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(65, 20)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Rectangle"
        Me.ToolTip1.SetToolTip(Me.Button1, resources.GetString("Button1.ToolTip"))
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(27, 125)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(65, 20)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Ellips"
        Me.ToolTip1.SetToolTip(Me.Button2, "Activate Draw Ellips" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Активация прорисовки " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "элипса" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(27, 189)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(65, 20)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "Color Reс"
        Me.ToolTip1.SetToolTip(Me.Button3, "Activate Draw Fill Rectangle" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Активация прорисовки " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "окрашенного прямоугольника")
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.Menu
        Me.Button4.Location = New System.Drawing.Point(27, 250)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(65, 20)
        Me.Button4.TabIndex = 15
        Me.Button4.Text = "Color Ell"
        Me.ToolTip1.SetToolTip(Me.Button4, "Activate Draw Fill Ellips" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Активация прорисовки" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "окрашенного элипса")
        Me.Button4.UseVisualStyleBackColor = False
        '
        'HScrollBar1
        '
        Me.HScrollBar1.Location = New System.Drawing.Point(4, 326)
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.HScrollBar1.Size = New System.Drawing.Size(119, 20)
        Me.HScrollBar1.TabIndex = 19
        Me.ToolTip1.SetToolTip(Me.HScrollBar1, "Gradient of Opacity" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Шкала прозрачности")
        Me.HScrollBar1.Value = 100
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Gainsboro
        Me.Button7.ForeColor = System.Drawing.Color.DarkRed
        Me.Button7.Location = New System.Drawing.Point(54, 459)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(72, 21)
        Me.Button7.TabIndex = 23
        Me.Button7.Text = "Create"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolTip1.SetToolTip(Me.Button7, "Create the picture in PB" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Создавайте изображения в буфере обмена." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Gainsboro
        Me.Button14.Location = New System.Drawing.Point(66, 538)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(41, 20)
        Me.Button14.TabIndex = 33
        Me.Button14.Text = "Text"
        Me.ToolTip1.SetToolTip(Me.Button14, resources.GetString("Button14.ToolTip"))
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(74, 479)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(49, 21)
        Me.Button8.TabIndex = 24
        Me.Button8.Text = "Save"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolTip1.SetToolTip(Me.Button8, "Save image from PB")
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(42, 372)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(83, 23)
        Me.Button12.TabIndex = 28
        Me.Button12.Text = "Some Invisible"
        Me.ToolTip1.SetToolTip(Me.Button12, "Invisible Top strings of elements and menu")
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.Gold
        Me.Button18.Location = New System.Drawing.Point(0, 84)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(23, 20)
        Me.Button18.TabIndex = 38
        Me.ToolTip1.SetToolTip(Me.Button18, "Hide Picture Signature /Show Picture Signature" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(33, 395)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(75, 21)
        Me.Button19.TabIndex = 39
        Me.Button19.Text = " Invisible All"
        Me.ToolTip1.SetToolTip(Me.Button19, "Invisible All groups of elements")
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(37, 500)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(54, 20)
        Me.Button9.TabIndex = 25
        Me.Button9.Text = "Return"
        Me.ToolTip1.SetToolTip(Me.Button9, "Return picture from " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Clip Board" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Возврат картинки из " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "буфера обмена")
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.Maroon
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.Location = New System.Drawing.Point(0, 0)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(23, 20)
        Me.Button13.TabIndex = 40
        Me.ToolTip1.SetToolTip(Me.Button13, "Hide draw elements." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Свернуть кластер")
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.Green
        Me.Button17.Image = CType(resources.GetObject("Button17.Image"), System.Drawing.Image)
        Me.Button17.Location = New System.Drawing.Point(0, 42)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(23, 20)
        Me.Button17.TabIndex = 41
        Me.ToolTip1.SetToolTip(Me.Button17, "Show draw elements." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Развернуть кластер")
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(0, 372)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(43, 23)
        Me.Button20.TabIndex = 42
        Me.Button20.Text = "Act"
        Me.Button20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolTip1.SetToolTip(Me.Button20, resources.GetString("Button20.ToolTip"))
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(90, 500)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(35, 20)
        Me.Button22.TabIndex = 44
        Me.Button22.Text = "CCb"
        Me.ToolTip1.SetToolTip(Me.Button22, "Cleare Clip Board." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Очищайте буфер обмена." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(0, 438)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(33, 21)
        Me.Button21.TabIndex = 45
        Me.Button21.Text = "Gr"
        Me.Button21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolTip1.SetToolTip(Me.Button21, "Градиентная заливка клиентской области." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(0, 394)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(33, 23)
        Me.Button25.TabIndex = 1
        Me.Button25.Text = "UP"
        Me.ToolTip1.SetToolTip(Me.Button25, "Upload Draw,Save Elements 3D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Разворачивайте окно рисования" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "с элементами 3D и со" &
        "хранения. ")
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(106, 520)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(20, 57)
        Me.Button23.TabIndex = 46
        Me.Button23.Text = "CPB"
        Me.Button23.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip1.SetToolTip(Me.Button23, "Return Picture signature," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "clear Picture Window")
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(0, 416)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(33, 23)
        Me.Button26.TabIndex = 2
        Me.Button26.Text = "BТ"
        Me.ToolTip1.SetToolTip(Me.Button26, "Back Tab, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Сворачивайте табло")
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(109, 396)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(17, 64)
        Me.Button24.TabIndex = 47
        Me.Button24.Text = "BGC"
        Me.ToolTip1.SetToolTip(Me.Button24, "Back Ground Color" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Цвет фона" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(2, 269)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(68, 20)
        Me.Button27.TabIndex = 0
        Me.Button27.Text = "DrGRRect"
        Me.ToolTip1.SetToolTip(Me.Button27, "Draw Rectangle With" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Gradient Color" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Рисование прямоугольников" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "разного размера с" &
        " градиентом" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " цветов, протягиванием.")
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(2, 288)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(68, 20)
        Me.Button28.TabIndex = 1
        Me.Button28.Text = "DrGREll"
        Me.ToolTip1.SetToolTip(Me.Button28, "Draw Ellipse with" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "color Gradient." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Прорисовывайте элипсы" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "разных размеров, прост" &
        "ым" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "протягиванием. ")
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(70, 269)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(56, 20)
        Me.Button29.TabIndex = 48
        Me.Button29.Text = "DrGrRR"
        Me.ToolTip1.SetToolTip(Me.Button29, "Draw  Fill color Rectangle " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "with random constellation" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " of color gradient and it" &
        "`s angle." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Рисуйте  прямоугольник," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "окраженный случайным сочетанием " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "цветов, по" &
        "д случайным углом.")
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(70, 288)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(56, 20)
        Me.Button30.TabIndex = 49
        Me.Button30.Text = "DrGrElR"
        Me.ToolTip1.SetToolTip(Me.Button30, "Draw  Fill color Ellipse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "with random constellation" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " of color gradient and it`s" &
        " angle." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Рисуйте  Эллипс," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "окаженный случайным сочетанием " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "цветов, под случайны" &
        "м углом." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(77, 415)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(33, 45)
        Me.Button31.TabIndex = 50
        Me.Button31.Text = "CG"
        Me.ToolTip1.SetToolTip(Me.Button31, "Draw color gradient" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "with abris and without" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Рисуйте цветовой " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "градиент с абрисо" &
        "м и без")
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.Color.Maroon
        Me.Button32.Location = New System.Drawing.Point(-1, 350)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(24, 23)
        Me.Button32.TabIndex = 51
        Me.ToolTip1.SetToolTip(Me.Button32, "Приоcтановка и восстановление" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "функциональности бегунка." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(91, 42)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(33, 20)
        Me.Button33.TabIndex = 4
        Me.Button33.Text = "Re"
        Me.ToolTip1.SetToolTip(Me.Button33, "Activate random color gradient multiple" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " rectangle." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Активируйте опцию прорисовк" &
        "и " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "веера прямоугольков в градиентной заливке" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "условно случайного выбора." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Pc- p" &
        "icture, опция активирована.")
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(92, 125)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(33, 20)
        Me.Button34.TabIndex = 52
        Me.Button34.Text = "Ell"
        Me.ToolTip1.SetToolTip(Me.Button34, "Activate random color gradient multiple ellipse" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Активация инструмента рисования" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " элипсов с условно случайным градиентом" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " цветов." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(92, 189)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(33, 20)
        Me.Button35.TabIndex = 53
        Me.Button35.Text = "RC"
        Me.ToolTip1.SetToolTip(Me.Button35, "Активация инструмента рисования веера" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " прямоугольников с условно случайным углом" &
        "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " распределения от линии рисования." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Activation of draw tool ""fan"" rectangles.")
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(92, 250)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(33, 20)
        Me.Button36.TabIndex = 54
        Me.Button36.Text = "EllC"
        Me.ToolTip1.SetToolTip(Me.Button36, "Активация инструмента рисования веера" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "овалов с условно случайным углом" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " распред" &
        "еления от линии рисования." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Activation of draw tool ""fan"" ellipses." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        Me.Button36.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(1, 460)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(49, 18)
        Me.TextBox4.TabIndex = 55
        Me.TextBox4.Text = "0"
        Me.ToolTip1.SetToolTip(Me.TextBox4, "Координаты Х исходной точки копирования," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "верхний левый угол.")
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(25, 539)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(43, 18)
        Me.TextBox5.TabIndex = 56
        Me.TextBox5.Text = "0"
        Me.ToolTip1.SetToolTip(Me.TextBox5, "Координаты Y исходной точки копирования," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "верхний левый угол." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(4, 482)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(14, 13)
        Me.RadioButton1.TabIndex = 57
        Me.ToolTip1.SetToolTip(Me.RadioButton1, resources.GetString("RadioButton1.ToolTip"))
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Checked = True
        Me.RadioButton2.Location = New System.Drawing.Point(16, 503)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(14, 13)
        Me.RadioButton2.TabIndex = 58
        Me.RadioButton2.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton2, resources.GetString("RadioButton2.ToolTip"))
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(27, 482)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(14, 13)
        Me.RadioButton3.TabIndex = 59
        Me.ToolTip1.SetToolTip(Me.RadioButton3, resources.GetString("RadioButton3.ToolTip"))
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(0, 519)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(22, 60)
        Me.Button38.TabIndex = 61
        Me.Button38.Text = "Accb"
        Me.ToolTip1.SetToolTip(Me.Button38, "Enter pictures nto CB" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Кнопка вставки изображения экрана, в клик, по " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " указателю" &
        " курсора.")
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(28, 557)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(75, 19)
        Me.Button15.TabIndex = 4
        Me.Button15.Text = "Insert"
        Me.ToolTip1.SetToolTip(Me.Button15, "Insert picture to the field of transformation.")
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(0, 579)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(70, 19)
        Me.Button16.TabIndex = 62
        Me.Button16.Text = "Past CB"
        Me.ToolTip1.SetToolTip(Me.Button16, "Insert picture to the field of transformation.")
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Timer2
        '
        Me.Timer2.Interval = 1
        '
        'Timer3
        '
        Me.Timer3.Interval = 1
        '
        'SaveFileDialog2
        '
        Me.SaveFileDialog2.DefaultExt = "*.jpeg;"
        Me.SaveFileDialog2.FileName = "Easy malbert"
        Me.SaveFileDialog2.Filter = resources.GetString("SaveFileDialog2.Filter")
        '
        'SaveFileDialog3
        '
        Me.SaveFileDialog3.DefaultExt = "*.jpeg;"
        Me.SaveFileDialog3.FileName = "Easy malbert"
        Me.SaveFileDialog3.Filter = resources.GetString("SaveFileDialog3.Filter")
        '
        'Timer4
        '
        Me.Timer4.Interval = 333
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(Me.PictureBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 40)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(130, 641)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Draw, Save elements 3D"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(4, 4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(123, 148)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage1.Controls.Add(Me.RadioButton4)
        Me.TabPage1.Controls.Add(Me.Button16)
        Me.TabPage1.Controls.Add(Me.Button15)
        Me.TabPage1.Controls.Add(Me.Button38)
        Me.TabPage1.Controls.Add(Me.RadioButton3)
        Me.TabPage1.Controls.Add(Me.RadioButton2)
        Me.TabPage1.Controls.Add(Me.RadioButton1)
        Me.TabPage1.Controls.Add(Me.TextBox5)
        Me.TabPage1.Controls.Add(Me.TextBox4)
        Me.TabPage1.Controls.Add(Me.TextBox2)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Controls.Add(Me.Button36)
        Me.TabPage1.Controls.Add(Me.Button35)
        Me.TabPage1.Controls.Add(Me.Button34)
        Me.TabPage1.Controls.Add(Me.Button33)
        Me.TabPage1.Controls.Add(Me.Button32)
        Me.TabPage1.Controls.Add(Me.Button31)
        Me.TabPage1.Controls.Add(Me.Button30)
        Me.TabPage1.Controls.Add(Me.Button29)
        Me.TabPage1.Controls.Add(Me.Button28)
        Me.TabPage1.Controls.Add(Me.Button27)
        Me.TabPage1.Controls.Add(Me.Button24)
        Me.TabPage1.Controls.Add(Me.Button26)
        Me.TabPage1.Controls.Add(Me.Button23)
        Me.TabPage1.Controls.Add(Me.Button25)
        Me.TabPage1.Controls.Add(Me.Button21)
        Me.TabPage1.Controls.Add(Me.Button22)
        Me.TabPage1.Controls.Add(Me.Button20)
        Me.TabPage1.Controls.Add(Me.Button17)
        Me.TabPage1.Controls.Add(Me.Button13)
        Me.TabPage1.Controls.Add(Me.Button9)
        Me.TabPage1.Controls.Add(Me.Button19)
        Me.TabPage1.Controls.Add(Me.Button18)
        Me.TabPage1.Controls.Add(Me.Button12)
        Me.TabPage1.Controls.Add(Me.Button11)
        Me.TabPage1.Controls.Add(Me.Button8)
        Me.TabPage1.Controls.Add(Me.Button14)
        Me.TabPage1.Controls.Add(Me.Button10)
        Me.TabPage1.Controls.Add(Me.Button5)
        Me.TabPage1.Controls.Add(Me.Button7)
        Me.TabPage1.Controls.Add(Me.Button6)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.HScrollBar1)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.ComboBox4)
        Me.TabPage1.Controls.Add(Me.ComboBox3)
        Me.TabPage1.Controls.Add(Me.ComboBox2)
        Me.TabPage1.Controls.Add(Me.ComboBox1)
        Me.TabPage1.ForeColor = System.Drawing.Color.DarkRed
        Me.TabPage1.Location = New System.Drawing.Point(4, 40)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TabPage1.Size = New System.Drawing.Size(130, 641)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Draw elements "
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox2.Location = New System.Drawing.Point(73, 103)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(50, 20)
        Me.TextBox2.TabIndex = 7
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox1.Location = New System.Drawing.Point(73, 22)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(50, 20)
        Me.TextBox1.TabIndex = 6
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(34, 437)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(43, 23)
        Me.Button11.TabIndex = 27
        Me.Button11.Text = "Color"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(32, 415)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 23)
        Me.Button10.TabIndex = 26
        Me.Button10.Text = "ColorL"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(18, 519)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(40, 20)
        Me.Button5.TabIndex = 21
        Me.Button5.Text = "Clear"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(54, 519)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(53, 20)
        Me.Button6.TabIndex = 22
        Me.Button6.Text = "DelateE"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.ForeColor = System.Drawing.Color.Maroon
        Me.Label6.Location = New System.Drawing.Point(25, 352)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 19)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "opacity"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Maroon
        Me.Label5.Location = New System.Drawing.Point(23, 310)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "poits"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Crimson
        Me.Label4.Location = New System.Drawing.Point(29, 212)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Color Ellips"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Crimson
        Me.Label3.Location = New System.Drawing.Point(29, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Color Rectangle"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Crimson
        Me.Label2.Location = New System.Drawing.Point(81, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Ellips"
        '
        'ComboBox4
        '
        Me.ComboBox4.BackColor = System.Drawing.SystemColors.Menu
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(25, 229)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(99, 21)
        Me.ComboBox4.TabIndex = 5
        '
        'ComboBox3
        '
        Me.ComboBox3.BackColor = System.Drawing.SystemColors.Menu
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(26, 165)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(99, 21)
        Me.ComboBox3.TabIndex = 4
        '
        'ComboBox2
        '
        Me.ComboBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(25, 81)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(99, 21)
        Me.ComboBox2.TabIndex = 3
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.SystemColors.Menu
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(26, 0)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(99, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(1084, 52)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TabControl1.RightToLeftLayout = True
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(138, 685)
        Me.TabControl1.TabIndex = 3
        '
        'Timer5
        '
        Me.Timer5.Interval = 333
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(51, 482)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(14, 13)
        Me.RadioButton4.TabIndex = 63
        Me.ToolTip1.SetToolTip(Me.RadioButton4, resources.GetString("RadioButton4.ToolTip"))
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1222, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(930, 764)
        Me.Name = "Form1"
        Me.Text = "Easy Malbert"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ЦветToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ServiceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpacityToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Opacity1ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents CreateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CreateToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SaveImageToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox2 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox3 As ToolStripTextBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents ToolStripComboBox1 As ToolStripComboBox
    Friend WithEvents ToolStripComboBox2 As ToolStripComboBox
    Friend WithEvents ReturnToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripComboBox3 As ToolStripComboBox
    Friend WithEvents ToolStripComboBox4 As ToolStripComboBox
    Friend WithEvents ToolStripTextBox4 As ToolStripTextBox
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents GradientBCkToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ЦветКонтураToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox5 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox6 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox8 As ToolStripTextBox
    Friend WithEvents InvisibleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ServiceToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents СведенияToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ОПрограммеToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents InvisibleAllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents ClearCBToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DelateToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveAndorRenameAndSaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveFileDialog2 As SaveFileDialog
    Friend WithEvents ClearPBToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripComboBox5 As ToolStripComboBox
    Friend WithEvents ToolStripComboBox6 As ToolStripComboBox
    Friend WithEvents ToolStripComboBox7 As ToolStripComboBox
    Friend WithEvents ToolStripButton4 As ToolStripButton
    Friend WithEvents ToolStripButton5 As ToolStripButton
    Friend WithEvents BackGraundColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents SaveFileDialog3 As SaveFileDialog
    Friend WithEvents CGToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox9 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox7 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox10 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox12 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox11 As ToolStripTextBox
    Friend WithEvents SaveFromScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripTextBox13 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox14 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox15 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox16 As ToolStripTextBox
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents ToolStripButton8 As ToolStripButton
    Friend WithEvents ToolStripButton7 As ToolStripButton
    Friend WithEvents ClearCBToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CopyToCBFromScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PastFromCBToScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Timer4 As Timer
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Button16 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button36 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents HScrollBar1 As HScrollBar
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents Timer5 As Timer
    Friend WithEvents ToolStripTextBox17 As ToolStripTextBox
    Friend WithEvents RadioButton4 As RadioButton
End Class
