﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DocumentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.КаскадToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СвернутьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.РазвернутьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ВосстановитьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ЗакрытьВсеToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.КонфиденциальностьToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.СведенияToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutEasyMalbertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox2 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox3 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.SeaGreen
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DocumentToolStripMenuItem, Me.WindowToolStripMenuItem, Me.ServiceToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.MdiWindowListItem = Me.WindowToolStripMenuItem
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DocumentToolStripMenuItem
        '
        Me.DocumentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.DocumentToolStripMenuItem.Name = "DocumentToolStripMenuItem"
        Me.DocumentToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.DocumentToolStripMenuItem.Text = "Document"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'WindowToolStripMenuItem
        '
        Me.WindowToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.КаскадToolStripMenuItem, Me.СвернутьВсеToolStripMenuItem, Me.РазвернутьВсеToolStripMenuItem, Me.ВосстановитьВсеToolStripMenuItem, Me.ЗакрытьВсеToolStripMenuItem, Me.КонфиденциальностьToolStripMenuItem})
        Me.WindowToolStripMenuItem.Name = "WindowToolStripMenuItem"
        Me.WindowToolStripMenuItem.Size = New System.Drawing.Size(63, 20)
        Me.WindowToolStripMenuItem.Text = "Window"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'КаскадToolStripMenuItem
        '
        Me.КаскадToolStripMenuItem.Name = "КаскадToolStripMenuItem"
        Me.КаскадToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.КаскадToolStripMenuItem.Text = "Каскад"
        '
        'СвернутьВсеToolStripMenuItem
        '
        Me.СвернутьВсеToolStripMenuItem.Name = "СвернутьВсеToolStripMenuItem"
        Me.СвернутьВсеToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.СвернутьВсеToolStripMenuItem.Text = "Свернуть все"
        '
        'РазвернутьВсеToolStripMenuItem
        '
        Me.РазвернутьВсеToolStripMenuItem.Name = "РазвернутьВсеToolStripMenuItem"
        Me.РазвернутьВсеToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.РазвернутьВсеToolStripMenuItem.Text = "Развернуть все"
        '
        'ВосстановитьВсеToolStripMenuItem
        '
        Me.ВосстановитьВсеToolStripMenuItem.Name = "ВосстановитьВсеToolStripMenuItem"
        Me.ВосстановитьВсеToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.ВосстановитьВсеToolStripMenuItem.Text = "Восстановить все"
        '
        'ЗакрытьВсеToolStripMenuItem
        '
        Me.ЗакрытьВсеToolStripMenuItem.Name = "ЗакрытьВсеToolStripMenuItem"
        Me.ЗакрытьВсеToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.ЗакрытьВсеToolStripMenuItem.Text = "Закрыть все"
        '
        'КонфиденциальностьToolStripMenuItem
        '
        Me.КонфиденциальностьToolStripMenuItem.Name = "КонфиденциальностьToolStripMenuItem"
        Me.КонфиденциальностьToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.КонфиденциальностьToolStripMenuItem.Text = "Конфиденциальность"
        '
        'ServiceToolStripMenuItem
        '
        Me.ServiceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.СведенияToolStripMenuItem, Me.AboutEasyMalbertToolStripMenuItem})
        Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
        Me.ServiceToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.ServiceToolStripMenuItem.Text = "Service"
        '
        'СведенияToolStripMenuItem
        '
        Me.СведенияToolStripMenuItem.Name = "СведенияToolStripMenuItem"
        Me.СведенияToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.СведенияToolStripMenuItem.Text = "Сведения"
        '
        'AboutEasyMalbertToolStripMenuItem
        '
        Me.AboutEasyMalbertToolStripMenuItem.Name = "AboutEasyMalbertToolStripMenuItem"
        Me.AboutEasyMalbertToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.AboutEasyMalbertToolStripMenuItem.Text = "About Easy Malbert"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.LemonChiffon
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripButton3, Me.ToolStripButton4, Me.ToolStripTextBox1, Me.ToolStripTextBox2, Me.ToolStripTextBox3, Me.ToolStripButton6})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1370, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(97, 22)
        Me.ToolStripButton1.Text = "Создать пароль"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(88, 22)
        Me.ToolStripButton2.Text = "Зашифровать"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(88, 22)
        Me.ToolStripButton3.Text = "Рашифровать"
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(134, 22)
        Me.ToolStripButton4.Text = "Проверить сложность"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(250, 25)
        '
        'ToolStripTextBox2
        '
        Me.ToolStripTextBox2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox2.Name = "ToolStripTextBox2"
        Me.ToolStripTextBox2.Size = New System.Drawing.Size(300, 25)
        '
        'ToolStripTextBox3
        '
        Me.ToolStripTextBox3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox3.Name = "ToolStripTextBox3"
        Me.ToolStripTextBox3.Size = New System.Drawing.Size(300, 25)
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(35, 22)
        Me.ToolStripButton6.Text = "Start"
        '
        'Timer1
        '
        Me.Timer1.Interval = 400
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1370, 548)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form3"
        Me.Text = "Easy Malbert"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents DocumentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WindowToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents КаскадToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents СвернутьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents РазвернутьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ВосстановитьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ЗакрытьВсеToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents КонфиденциальностьToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents ToolStripButton4 As ToolStripButton
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox2 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox3 As ToolStripTextBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ServiceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents СведенияToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutEasyMalbertToolStripMenuItem As ToolStripMenuItem
End Class
