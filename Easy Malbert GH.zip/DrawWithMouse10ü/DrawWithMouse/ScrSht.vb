﻿Module ScrSht
    Private Declare Function CreateDC Lib "GDI32" Alias "CreateDCA" (IpDriverName As String, IpDeviceName As String, IpOutput As String, IpInitData As String) As IntPtr
    Private Declare Function CreateCompatibleDC Lib "GDI32" (hDC As IntPtr) As IntPtr
    Private Declare Function CreateCompatibleBitmap Lib "GDI32" (hDC As IntPtr, nWidth As Integer, nHeight As Integer) As IntPtr
    Private Declare Function SelectObject Lib "GDI32" (hDC As IntPtr, hObject As IntPtr) As IntPtr
    Private Declare Function BitBlt Lib "GDI32" (srchDC As IntPtr, srcX As Integer, srcY As Integer, srcW As Integer, srcH As Integer, desthDC As IntPtr, destX As Integer, destY As Integer, op As Integer) As Integer
    Private Declare Function DeleteDC Lib "GDI32" (hDC As IntPtr) As Integer

    Private Declare Function DeleteObject Lib "GDI32" (hObj As IntPtr) As Integer



    Const SRCCOPY As Integer = &HCC0020

    Public Function GetImage() As Bitmap
        ' Выполняем захват экрана.
        Dim screenHandle As IntPtr
        Dim canvasHandle As IntPtr
        Dim screenBitmap As IntPtr
        Dim previousObject As IntPtr
        Dim resultCode As Integer
        Dim screenShot As Bitmap

        ' Получаем ссылку экрана.
        screenHandle = CreateDC("DISPLAY", "", "", "")
        'Создаем точно такой же холст, как и холст экрана.
        canvasHandle = CreateCompatibleDC(screenHandle)
        ' создаем битовую карту для хранения изображения экрана.
        screenBitmap = CreateCompatibleBitmap(screenHandle, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height)
        'копируем изображение экрана в битовую карту(холст).
        previousObject = SelectObject(canvasHandle, screenBitmap)
        resultCode = BitBlt(canvasHandle, 0, 0, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, screenHandle, 0, 0, SRCCOPY)
        screenBitmap = SelectObject(canvasHandle, previousObject)


        ' работа с холстом завершена
        resultCode = DeleteDC(screenHandle)
        resultCode = DeleteDC(canvasHandle)
        'копируем изображение в битовую карту .Net.
        screenShot = Image.FromHbitmap(screenBitmap)
        DeleteObject(screenBitmap)

        'Закончено.
        Return screenShot
    End Function


End Module
